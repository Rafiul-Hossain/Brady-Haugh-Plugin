<?php
namespace Tapedb\Helper;

if (!defined('ABSPATH')) { exit; }

// Load Entries module (4-file pattern)
require_once TAPEDB_PLUGIN_PATH . 'app/TableCreator.php';
require_once TAPEDB_PLUGIN_PATH . 'app/entries_validation.php';
require_once TAPEDB_PLUGIN_PATH . 'app/entries_controller.php';
require_once TAPEDB_PLUGIN_PATH . 'app/entries_routes.php';
