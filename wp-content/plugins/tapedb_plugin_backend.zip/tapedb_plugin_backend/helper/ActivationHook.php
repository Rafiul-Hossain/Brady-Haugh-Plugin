<?php
namespace Tapedb\Helper;

if (!defined('ABSPATH')) { exit; }

use Tapedb\App\Entries\TableCreator as EntriesTable;

class ActivationHook {
    public static function activate() {
        try {
            // Create DB tables
            EntriesTable::create_table();

            // Create custom role
            self::ensure_bradys_assistant_role();

            // Flush rewrites
            flush_rewrite_rules();

            // Optional: set an option so we know activation ran
            update_option('tapedb_activated_ok', time());
        } catch (\Throwable $e) {
            // Log and rethrow so WP shows “fatal error” with details in debug.log
            if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
                error_log('[tapedb_plugin_backend] Activation error: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
            }
            throw $e;
        }
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    private static function ensure_bradys_assistant_role() {
        $role_key = 'bradys_assistant';
        if (!get_role($role_key)) {
            $subscriber = get_role('subscriber');
            $caps = $subscriber ? $subscriber->capabilities : [];
            add_role($role_key, "brady's assistant", $caps);
        }
    }
}
