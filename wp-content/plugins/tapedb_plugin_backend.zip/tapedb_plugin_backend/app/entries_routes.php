<?php
namespace Tapedb\App\Entries;

if (!defined('ABSPATH')) { exit; }

const TAPEDB_NS = 'tapedb/v2';

// --- role helpers ---
function tapedb_is_admin() {
    return current_user_can('manage_options');
}
function tapedb_is_assistant() {
    $u = wp_get_current_user();
    return $u && is_user_logged_in() && in_array('bradys_assistant', (array)$u->roles, true);
}
function tapedb_logged_in_creator() {
    return is_user_logged_in() && (tapedb_is_admin() || tapedb_is_assistant());
}

// --- ownership checks (read DB row and compare user_id) ---
function tapedb_user_owns_entry($entry_id) {
    global $wpdb;
    $table = TableCreator::table_name();
    $uid   = get_current_user_id();
    if (!$uid) return false;
    $owner = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE id=%d", $entry_id));
    return $owner > 0 && $owner === (int)$uid;
}

// CREATE: admin or assistant (logged-in)
function tapedb_can_create() {
    return tapedb_logged_in_creator();
}

// UPDATE: admin OR (assistant AND owns row)
function tapedb_can_update($request) {
    if (tapedb_is_admin()) return true;
    if (!tapedb_is_assistant()) return false;
    $id = intval($request['id']);
    return tapedb_user_owns_entry($id);
}

// DELETE: admin OR (assistant AND owns row)
function tapedb_can_delete($request) {
    if (tapedb_is_admin()) return true;
    if (!tapedb_is_assistant()) return false;
    $id = intval($request['id']);
    return tapedb_user_owns_entry($id);
}

function tapedb_register_entries_routes() {
    register_rest_route(TAPEDB_NS, '/entries', [
        [
            'methods'  => 'GET',
            'callback' => [EntriesController::class, 'index'],
            'permission_callback' => '__return_true',
            'args' => [
                'search'     => ['description' => 'Multi-token search (AND across tokens, OR across fields)'],
                'start_year' => ['description' => 'Inclusive start year filter'],
                'end_year'   => ['description' => 'Inclusive end year filter'],
                'page'       => ['description' => 'Page number'],
                'per_page'   => ['description' => 'Items per page'],
            ],
        ],
        [
            'methods'  => 'POST',
            'callback' => Validator::wrap([EntriesController::class, 'store'], 'store'),
            'permission_callback' => __NAMESPACE__ . '\\tapedb_can_create',
        ],
    ]);

    register_rest_route(TAPEDB_NS, '/entries/(?P<id>\\d+)', [
        [
            'methods'  => 'GET',
            'callback' => [EntriesController::class, 'show'],
            'permission_callback' => '__return_true',
        ],
        [
            // keep PUT,PATCH; you can also add POST here if your stack struggles with PUT + multipart
            'methods'  => 'PUT,PATCH,POST',
            'callback' => Validator::wrap([EntriesController::class, 'update'], 'update'),
            'permission_callback' => __NAMESPACE__ . '\\tapedb_can_update',
        ],
        [
            'methods'  => 'DELETE',
            'callback' => [EntriesController::class, 'destroy'],
            'permission_callback' => __NAMESPACE__ . '\\tapedb_can_delete',
        ],
    ]);
}

add_action('rest_api_init', __NAMESPACE__ . '\\tapedb_register_entries_routes');
