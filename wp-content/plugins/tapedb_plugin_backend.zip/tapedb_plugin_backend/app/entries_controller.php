<?php

namespace Tapedb\App\Entries;

if (!defined('ABSPATH')) {
    exit;
}

class EntriesController
{

    // ----------------- helpers -----------------

    private static function save_upload_to_media(array $file)
    {
        if (empty($file) || empty($file['name'])) {
            return new \WP_Error('no_file', 'No file provided');
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $overrides = ['test_form' => false];
        $movefile  = \wp_handle_upload($file, $overrides);
        if (!isset($movefile['file'])) {
            $msg = isset($movefile['error']) ? $movefile['error'] : 'Upload failed';
            return new \WP_Error('upload_failed', $msg);
        }

        $filetype   = \wp_check_filetype(basename($movefile['file']), null);
        $attachment = [
            'post_mime_type' => $filetype['type'],
            'post_title'     => sanitize_file_name(pathinfo($movefile['file'], PATHINFO_FILENAME)),
            'post_content'   => '',
            'post_status'    => 'inherit'
        ];

        $attach_id = \wp_insert_attachment($attachment, $movefile['file']);
        if (is_wp_error($attach_id)) {
            return $attach_id;
        }

        $attach_data = \wp_generate_attachment_metadata($attach_id, $movefile['file']);
        \wp_update_attachment_metadata($attach_id, $attach_data);

        $url = \wp_get_attachment_url($attach_id);
        return $url ?: new \WP_Error('no_url', 'Could not get attachment URL');
    }

    private static function collect_uploaded_images($request): array
    {
        $out   = [];
        $files = $request->get_file_params() ?: [];
        foreach (['img1', 'img2', 'img3', 'img4', 'img5', 'img6'] as $key) {
            if (!empty($files[$key]) && !empty($files[$key]['name'])) {
                $result = self::save_upload_to_media($files[$key]);
                if (is_wp_error($result)) {
                    return ['__error' => $result];
                }
                $out[$key] = $result; // URL
            }
        }
        return $out;
    }

    private static function read_body_params($request): array
    {
        // Robust body extraction: JSON → urlencoded/body → generic → $_POST
        $data = $request->get_json_params();
        if (!is_array($data) || empty($data)) {
            $data = $request->get_body_params(); // often works for urlencoded/multipart
        }
        if (!is_array($data) || empty($data)) {
            $data = $request->get_params(); // may include query params
        }
        if (!is_array($data) || empty($data)) {
            $data = $_POST ?: [];
        }
        return is_array($data) ? $data : [];
    }

    // ----------------- read endpoints -----------------

    public static function index($request)
    {
        global $wpdb;
        $table = TableCreator::table_name();

        $page     = max(1, intval($request->get_param('page') ?: 1));
        $per_page = max(1, intval($request->get_param('per_page') ?: 10));
        $offset   = ($page - 1) * $per_page;

        $search     = trim((string)($request->get_param('search') ?? ''));
        $start_year = trim((string)($request->get_param('start_year') ?? ''));
        $end_year   = trim((string)($request->get_param('end_year') ?? ''));

        $where  = ['1=1'];
        $params = [];

        // ----- Search: multi-token AND; OR across fields; case-insensitive -----
        if ($search !== '') {
            $norm   = function_exists('mb_strtolower') ? mb_strtolower($search) : strtolower($search);
            $tokens = preg_split('/\s+/', $norm, -1, PREG_SPLIT_NO_EMPTY);

            $fields = ['name', 'title', 'distributor', 'case_desc', 'seal', 'sticker', 'watermarks', 'etching', 'notes', 'guard_color', 'upc'];
            $andClauses = [];

            foreach ($tokens as $tok) {
                $like    = '%' . $wpdb->esc_like($tok) . '%';
                $orParts = [];
                foreach ($fields as $f) {
                    // LOWER(col) LIKE %s to force case-insensitive match even on CS collations
                    $orParts[] = "LOWER($f) LIKE %s";
                    $params[]  = $like;
                }
                $andClauses[] = '(' . implode(' OR ', $orParts) . ')';
            }
            if (!empty($andClauses)) {
                $where[] = implode(' AND ', $andClauses);
            }
        }

        // ----- Year range: prefer numeric compare when bounds look numeric -----
        if ($start_year !== '') {
            if (preg_match('/^\d{1,4}$/', $start_year)) {
                $where[] = 'CAST(year AS UNSIGNED) >= %d';
                $params[] = (int)$start_year;
            } else {
                $where[] = 'year >= %s';
                $params[] = $start_year;
            }
        }
        if ($end_year !== '') {
            if (preg_match('/^\d{1,4}$/', $end_year)) {
                $where[] = 'CAST(year AS UNSIGNED) <= %d';
                $params[] = (int)$end_year;
            } else {
                $where[] = 'year <= %s';
                $params[] = $end_year;
            }
        }

        $whereSql = implode(' AND ', $where);

        // Count
        $count_sql = $wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE $whereSql", $params);
        $total     = (int) $wpdb->get_var($count_sql);

        // Data
        $data_sql = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE $whereSql ORDER BY id DESC LIMIT %d OFFSET %d",
            array_merge($params, [(int)$per_page, (int)$offset])
        );
        $rows = $wpdb->get_results($data_sql, ARRAY_A);

        return new \WP_REST_Response([
            'status'       => true,
            'message'      => 'Entries fetched successfully.',
            'data'         => $rows,
            'search'       => $search,
            'current_page' => $page,
            'per_page'     => $per_page,
            'total_pages'  => (int) ceil($total / $per_page),
        ], 200);
    }


    public static function show($request)
    {
        global $wpdb;
        $table = TableCreator::table_name();
        $id = intval($request['id']);

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$row) {
            return new \WP_REST_Response(['status' => false, 'message' => 'Not found'], 404);
        }
        return new \WP_REST_Response([
            'status'  => true,
            'message' => 'Entry fetched successfully.',
            'data'    => $row,
        ], 200);
    }

    // ----------------- write endpoints (permissions handled in routes) -----------------

    public static function store($request)
    {
        global $wpdb;
        $table = TableCreator::table_name();

        $data     = self::read_body_params($request);
        $uploaded = self::collect_uploaded_images($request);
        if (isset($uploaded['__error']) && is_wp_error($uploaded['__error'])) {
            return new \WP_REST_Response(['status' => false, 'message' => $uploaded['__error']->get_error_message()], 400);
        }

        $allowed = [
            'user_id',
            'name',
            'title',
            'year',
            'distributor',
            'case_desc',
            'seal',
            'sticker',
            'watermarks',
            'etching',
            'notes',
            'qa_checked',
            'guard_color',
            'upc',
            'img1',
            'img2',
            'img3',
            'img4',
            'img5',
            'img6',
            'approved'
        ];

        $insert = [];
        foreach ($allowed as $k) {
            if (array_key_exists($k, $data)) {
                $insert[$k] = $data[$k];
            }
        }
        foreach ($uploaded as $k => $v) {
            $insert[$k] = $v;
        }

        // Force owner for non-admins; default to current user if admin omitted it
        $current_uid = get_current_user_id();
        if (!current_user_can('manage_options')) {
            $insert['user_id'] = $current_uid;
        } else {
            if (!isset($insert['user_id']) || !$insert['user_id']) {
                $insert['user_id'] = $current_uid;
            }
        }

        $ok = $wpdb->insert($table, $insert);
        if ($ok === false) {
            return new \WP_REST_Response(['status' => false, 'message' => 'Insert failed'], 500);
        }
        $id = (int) $wpdb->insert_id;
        return new \WP_REST_Response([
            'status'  => true,
            'message' => 'Entry created successfully.',
            'id'      => $id,
        ], 201);
    }

    public static function update($request)
    {
        global $wpdb;
        $table = TableCreator::table_name();

        $id       = intval($request['id']);
        $data     = self::read_body_params($request);
        $uploaded = self::collect_uploaded_images($request);
        if (isset($uploaded['__error']) && is_wp_error($uploaded['__error'])) {
            return new \WP_REST_Response(['status' => false, 'message' => $uploaded['__error']->get_error_message()], 400);
        }

        $allowed = [
            'user_id',
            'name',
            'title',
            'year',
            'distributor',
            'case_desc',
            'seal',
            'sticker',
            'watermarks',
            'etching',
            'notes',
            'qa_checked',
            'guard_color',
            'upc',
            'img1',
            'img2',
            'img3',
            'img4',
            'img5',
            'img6',
            'approved'
        ];

        $update = [];
        foreach ($allowed as $k) {
            if (array_key_exists($k, $data)) {
                $update[$k] = $data[$k];
            }
        }
        foreach ($uploaded as $k => $v) {
            $update[$k] = $v;
        }

        // Non-admins cannot change ownership
        if (!current_user_can('manage_options')) {
            unset($update['user_id']);
        }

        if (empty($update)) {
            return new \WP_REST_Response(['status' => false, 'message' => 'No fields to update'], 400);
        }

        $ok = $wpdb->update($table, $update, ['id' => $id]);
        if ($ok === false) {
            return new \WP_REST_Response(['status' => false, 'message' => 'Update failed'], 500);
        }
        return new \WP_REST_Response([
            'status'  => true,
            'message' => 'Entry updated successfully.',
            'id'      => $id,
        ], 200);
    }

    public static function destroy($request)
    {
        global $wpdb;
        $table = TableCreator::table_name();

        $id = intval($request['id']);
        $ok = $wpdb->delete($table, ['id' => $id]);
        if ($ok === false) {
            return new \WP_REST_Response(['status' => false, 'message' => 'Delete failed'], 500);
        }
        return new \WP_REST_Response([
            'status'  => true,
            'message' => 'Entry deleted successfully.',
        ], 200);
    }
}
