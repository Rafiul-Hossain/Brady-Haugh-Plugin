<?php
/**
 * Plugin Name: tapedb_plugin_backend
 * Description: Tape DB backend (module-style). Routes under tapedb/v2.
 * Author: rafiul
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) { exit; }

// === Constants (clean main) ===
define('TAPEDB_PLUGIN_VERSION', '1.0.0');
define('TAPEDB_MAIN_FILE', __FILE__);
define('TAPEDB_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('TAPEDB_PLUGIN_URL', plugin_dir_url(__FILE__));

// === Requires (clean main) ===
require_once TAPEDB_PLUGIN_PATH . 'helper/AllLoadingFiles.php';
require_once TAPEDB_PLUGIN_PATH . 'helper/ActivationHook.php';

// === High-level hooks only ===
register_activation_hook(TAPEDB_MAIN_FILE, ['\\Tapedb\\Helper\\ActivationHook', 'activate']);
register_deactivation_hook(TAPEDB_MAIN_FILE, ['\\Tapedb\\Helper\\ActivationHook', 'deactivate']);

// Modules self-register routes via rest_api_init.
