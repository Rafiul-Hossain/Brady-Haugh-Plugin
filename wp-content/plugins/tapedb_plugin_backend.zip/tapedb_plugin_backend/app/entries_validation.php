<?php
namespace Tapedb\App\Entries;

if (!defined('ABSPATH')) { exit; }

class Validator {
    public static function wrap(callable $handler, $action) {
        return function($request) use ($handler, $action) {
            $errors = self::validate($request, $action);
            if (!empty($errors)) {
                return new \WP_REST_Response([
                    'status'  => false,
                    'message' => 'Validation failed',
                    'errors'  => $errors,
                ], 422);
            }
            return call_user_func($handler, $request);
        };
    }

    private static function validate($request, $action) {
        $errors = [];

        // Accept JSON or multipart/form-data text fields
        $data = $request->get_json_params();
        if (!is_array($data) || empty($data)) {
            $data = $request->get_params();
            if (!is_array($data)) { $data = []; }
        }

        // Helpers compatible with PHP 7.0
        $len = function($v) {
            return is_string($v) ? mb_strlen($v) : 0;
        };
        $isBoolish = function($v) {
            return ($v === 0 || $v === 1 || $v === '0' || $v === '1' || $v === true || $v === false);
        };

        // Length caps
        $caps = array(
            'name'        => 191,
            'title'       => 191,
            'year'        => 50,
            'distributor' => 255,
            'qa_checked'  => 10,
            'guard_color' => 255,
            'upc'         => 255,
            'img1'        => 255,
            'img2'        => 255,
            'img3'        => 255,
            'img4'        => 255,
            'img5'        => 255,
            'img6'        => 255,
        );

        switch ($action) {
            case 'store':
                if (!isset($data['name']) || trim((string)$data['name']) === '') {
                    $errors['name'] = 'name is required';
                }
                foreach ($caps as $field => $max) {
                    if (array_key_exists($field, $data) && is_string($data[$field]) && $len($data[$field]) > $max) {
                        $errors[$field] = $field . " must be at most " . $max . " characters";
                    }
                }
                if (array_key_exists('approved', $data) && !$isBoolish($data['approved'])) {
                    $errors['approved'] = 'approved must be boolean/0/1';
                }
                break;

            case 'update':
                foreach ($caps as $field => $max) {
                    if (array_key_exists($field, $data) && is_string($data[$field]) && $len($data[$field]) > $max) {
                        $errors[$field] = $field . " must be at most " . $max . " characters";
                    }
                }
                if (array_key_exists('approved', $data) && !$isBoolish($data['approved'])) {
                    $errors['approved'] = 'approved must be boolean/0/1';
                }
                break;

            case 'index':
            case 'show':
            case 'destroy':
                // no-op
                break;
        }

        return $errors;
    }
}
